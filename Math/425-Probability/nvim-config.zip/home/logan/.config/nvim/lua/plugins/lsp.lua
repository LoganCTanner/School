return {
  "neovim/nvim-lspconfig",
  event = { "BufReadPre", "BufNewFile" },
  config = function()
    -- Apply capabilities to all servers at once
    vim.lsp.config('*', {
      capabilities = require("cmp_nvim_lsp").default_capabilities()
    })

    -- C#/.NET needs extra options
    vim.lsp.config('omnisharp', {
      cmd = { "omnisharp", "--languageserver", "--hostPID", tostring(vim.fn.getpid()) },
      enable_editorconfig_support = true,
      enable_roslyn_analyzers = true,
      organize_imports_on_format = true,
    })

    vim.lsp.enable({
      'pyright',
      'ts_ls',      -- was tsserver
      'html',
      'cssls',
      'jsonls',
      'omnisharp',
      'texlab',
      'markdown',
    })
  end,
}
